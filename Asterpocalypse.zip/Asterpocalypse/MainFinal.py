# Author: Harmehar Singh 
# Date: November 1st 2020
# Class: ICS4U with Mr. Bulhao
# Program: Asterpocalypse
# Description: In this program you play as a spaceship that is trying to destroy all the asteroids that come its way

#I imported the Tk, Canvas, PhotoImage, and messagebox modules from tkinter
from tkinter import Tk, Canvas, PhotoImage, messagebox
#I imported the Spaceship class from SpaceshipFinal, the Asteroid class from AsteriodFinal, and the Bullet class from BulletFinal
from SpaceshipFinal import Spaceship
from AsteriodFinal import Asteroid
from BulletFinal import Bullet
#I imported the pygame module
import pygame
#I imported the random and math module from Python
import random, math

#I initialized two lists called Bullets and Asteroids as well as a variable named health
Bullets= []
Asteroids= []
health=10
#This function exits the program when the user clicks the exit button
def exit_program():
    global btid, gameid, collisionSpaceshipId, collisionBulletId
    #The btid, gameid, collisionSpaceshipId, collisionBulletId timers are stopped
    root.after_cancel(btid)
    root.after_cancel(gameid)
    root.after_cancel(collisionSpaceshipId)
    root.after_cancel(collisionBulletId)
    answer = messagebox.askyesno("", "Are you sure you want to exit?")
    
    if answer == True:
        messagebox.showinfo("Asterpocalypse", "Thank you for playing Asterpocalypse")
        exit()
    else:
        #The btid, gameid, collisionSpaceshipId, and collisionBulletId timers are restarted here
        btid = root.after(50, lambda: background_timer())
        gameid= root.after(60, lambda: game())
        collisionSpaceshipId= root.after(20, collisionCheckSpaceship)
        collisionBulletId= root.after(20, collisionCheckBullets)
#This function helps move the background
def background_timer():
    global btid
    for i in range(len(background_list)):
        canvas.coords(background_list[i], xpos[i] - 5, 0)
        xpos[i] -= 5

    btid = root.after(50, lambda: background_timer())
    root.update()
    
    if xpos[0] + imgBackground.width() <= 0:
        xpos[0] = xpos[1] + imgBackground.width()
    if xpos[1] + imgBackground.width() <= 0:
        xpos[1] = xpos[0] + imgBackground.width()
#This function does many different things under one timer
def game():
    global gameid, health
    #I created a new timer and set the timerID as gameid
    gameid= root.after(60, lambda: game())
    #The update() function is called here
    root.update()
    #The commands below run using every bullet object in the Bullets list
    for bullet in Bullets:
        #The fireBullet() function is called here
        bullet.fireBullet()
        #If the bullet's x position is bigger than the width of the canvas, the bullet is removed from the Bullets list and deleteBulletImage() is called
        if bullet.getX() > canvas.winfo_reqwidth():
            Bullets.remove(bullet)
            bullet.deleteBulletImage()
    #The commands below run using every asteroid object in the Asteroids list        
    for asteroid in Asteroids:
        #The move() function is called here
        asteroid.move()
        #If the asteroid's x position plus the width of the asteroid is smaller than or equal to 0, then the commands below would run
        if asteroid.getX() + asteroid.getWidth() <= 0:
            #The asteroid is removed from the Asteroids list
            Asteroids.remove(asteroid)
            #health decreases by 1 and checkhealth() is called
            health-=1
            checkhealth()
            #The generateAsteroid function is called here and assigned to the a variable
            a= generateAsteroid(canvas)
            #a is added to the Asteroids list
            Asteroids.append(a) 
#This function checks to see if the spaceship has collided with any asteroid when it is called to run
def collisionCheckSpaceship():
    global collisionSpaceshipId, Asteroid
    #A new timer is created here and I set the timerID to be collisionSpaceshipId              
    collisionSpaceshipId= root.after(20, collisionCheckSpaceship)
    #The commands below run using every asteroid object in the Asteroids list 
    for asteroid in Asteroids:
        #If the asteroid's left side is smaller than or equal to the spaceship's right side and the asteroid's right side is bigger than or equal to the spaceship's left side, the commands below run
        if asteroid.getBoundsObject()[0] <= spaceship.getBoundsObject()[2] and asteroid.getBoundsObject()[2] >= spaceship.getBoundsObject()[0]:
            #If the top of the asteroid is smaller than or equal to the bottom of the spaceship and the bottom of the asteroid is bigger than or equal to the top of the spaceship, the commands below will run
            if asteroid.getBoundsObject()[1] <= spaceship.getBoundsObject()[3] and asteroid.getBoundsObject()[3] >= spaceship.getBoundsObject()[1]:
                #The destroySpaceship() function is called here and the resulting value is assigned to lives
                lives= spaceship.destroySpaceship()
                #The playSound() function is called here
                playSound(1)
                #The setSpaceshipLives() function is called here
                spaceship.setSpaceshipLives(x=820, y=40, live=lives)
                #The btid, gameid, collisionSpaceshipId, collisionBulletId timers are stopped
                root.after_cancel(btid)
                root.after_cancel(gameid)
                root.after_cancel(collisionSpaceshipId)
                root.after_cancel(collisionBulletId)
                #If lives is 0 then the askPlayAgain() function is called, otherwise askPlayAfterLostLife() is called
                if lives == 0:
                    askPlayAgain()
                else:
                    askPlayAfterLostLife()
#This function checks to see if any bullet has collided with any asteroid when it is called to run                    
def collisionCheckBullets():
    global collisionBulletId, Bullets, pointsSpaceship, textpointsSpaceship
    #A new timer is created here and I set the timerID to be collisionBulletId      
    collisionBulletId= root.after(20, collisionCheckBullets)
    #The commands below run using every bullet object in the Bullets list    
    for bullet in Bullets:
        #The commands below run using every asteroid object in the Asteroids list
        for asteroid in Asteroids:
            #If the asteroid's left side is smaller than or equal to the bullet's right side and the asteroid's right side is bigger than or equal to the bullet's left side, the commands below will run
            if asteroid.getBoundsObject()[0] <= bullet.getBoundsObject()[2] and asteroid.getBoundsObject()[2] >= bullet.getBoundsObject()[0]:
                #If the top of the asteroid is smaller than or equal to the bottom of the bullet and the bottom of the asteroid is bigger than or equal to the top of the bullet, the commands below will run
                if asteroid.getBoundsObject()[1] <= bullet.getBoundsObject()[3] and asteroid.getBoundsObject()[3] >= bullet.getBoundsObject()[1]:
                    #The destroyAsteroid() function is called here and the resulting value is assigned to the lives variable
                    lives= asteroid.destroyAsteroid()
                    #The playSound() function is called here
                    playSound(1)
                    #the bullet object is removed from Bullets
                    Bullets.remove(bullet)
                    #The deleteBulletImage() function is called here
                    bullet.deleteBulletImage()
                    #If lives is equal to 0, then the commands below will run
                    if lives == 0:
                        #setPointsSpaceship() is called and the resulting value is assigned to the variable points
                        points= asteroid.setPointsSpaceship()
                        #points is added to pointsSpaceship
                        pointsSpaceship += points
                        #textpointsSpaceship is configured to show the updated pointsSpaceship
                        canvas.itemconfig(textpointsSpaceship, text=str(pointsSpaceship))
                        #The asteroid object is removed from Asteroids
                        Asteroids.remove(asteroid)
                        #A timer is created which deletes the exploded asteroid after one second using the deleteAsteroidImg() function
                        deleteAsteroidId= root.after(1000, asteroid.deleteAsteroidImg)
                        #The generateAsteroid() function is called here and the resulting value is assigned to the asteroid variable
                        asteroid= generateAsteroid(canvas)
                        #asteroid is appended to the Asteroids list
                        Asteroids.append(asteroid)
                    break
# This function gets the health bar of the the spaceship as the asteroids crosses the left side of the window
def checkhealth():
    global health, points, asteroid
    if health == 10:
        canvas.itemconfig(cvshealth, image=healthimg[0])
    elif health == 9:
        canvas.itemconfig(cvshealth, image=healthimg[1])  
    elif health == 8:
        canvas.itemconfig(cvshealth, image=healthimg[2])
    elif health == 7:
        canvas.itemconfig(cvshealth, image=healthimg[3])
    elif health == 6:
        canvas.itemconfig(cvshealth, image=healthimg[4])
    elif health == 5:
        canvas.itemconfig(cvshealth, image=healthimg[5])
    elif health == 4:
        canvas.itemconfig(cvshealth, image=healthimg[6])
    elif health == 3:
        canvas.itemconfig(cvshealth, image=healthimg[7])
    elif health == 2:
        canvas.itemconfig(cvshealth, image=healthimg[8])
    elif health == 1:
        canvas.itemconfig(cvshealth, image=healthimg[9])
    elif health == 0:
        canvas.itemconfig(cvshealth, image=healthimg[10])
        lives= spaceship.destroySpaceship()
        playSound(1)
        #The setSpaceshipLives() function is called here
        spaceship.setSpaceshipLives(x=820, y=40, live=lives)
        #The btid, gameid, collisionSpaceshipId, collisionBulletId timers are stopped
        root.after_cancel(btid)
        root.after_cancel(gameid)
        root.after_cancel(collisionSpaceshipId)
        root.after_cancel(collisionBulletId)
        ##If lives is equal to 0, then askPlayAgain() is called, otherwise, askPlayAfterLostLife() is called
        if lives == 0:
            askPlayAgain()
        else:
            askPlayAfterLostLife()
#This function checks to see if the user has clicked certain keyboard characters and it moves the spaceship a certain direction if a certain keyboard character was clicked               
def onKeyPress(event):
    #If the user clicks the "D" button, the move function is used to move the x position of the spaceship by 9 pixels
    if event.char == "d":
        spaceship.move(x=9)
    #If the user clicks the "A" button, the move function is used to move the x position of the spaceship by -9 pixels
    elif event.char == "a":
        spaceship.move(x=-9) 
    #If the user clicks the "W" button, the move function is used to move the y position of the spaceship by -9 pixels  
    elif event.char == "w":
        spaceship.move(y=-9)
    #If the user clicks the "W" button, the move function is used to move the y position of the spaceship by 9 pixels  
    elif event.char == "s":
        spaceship.move(y=9)
    #The setSpaceshipBoundaries function is called here to check that the spaceship is within its boundaries each time the spaceship moves
    spaceship.setSpaceshipBoundaries(xbounds=0, ybounds=70)
#This function fires a bullet from the spaceship if the user clicks a mouse button
def onMouseClick(event):
    global bullet, Bullets
    if len(Bullets) < 6:
        #A new bullet object is created here
        bullet= Bullet(canvas)
        #I called the setLocation() function here in order to set the location where the bullet will first appear
        bullet.setLocation(spaceship.getX() + spaceship.getWidth() - 10, spaceship.getY() + spaceship.getHeight() // 4)
        #I added the bullet object to the Bullets list
        Bullets.append(bullet)
        #I called the fireBullet() function here in order to actually fire the bullet
        bullet.fireBullet()
        playSound(0)
#This function randomly generates an asteroid's properties and then uses said properties to create an asteroid
def generateAsteroid(canvas):
    #The size of the asteroid is randomly generated here 
    typeAsteroid= random.randint(1, 3)
    #The x position of the asteroid is randomly generated here. Each asteroid is generated on the right side of the window
    x= random.randint(1000, 4000)
    #he y position of the asteroid is randomly generated here
    y= random.randint(70, 400)
    #An asteroid object is created here using the properties that were randomly created above
    asteroid= Asteroid(canvas, typeAsteroid, x, y)
    #collided is set to False
    collided= False
    #The for loop below runs using all the asteroids that are already in Asteroids
    for others in Asteroids:
        #I used pythagorean theorem as a distance formula in order to find the distance between asteroid and others (dict)
        dist = math.sqrt((others.getX() - asteroid.getX())**2 + (others.getY() - asteroid.getY())**2)
        #If dist is smaller than 200, collided is set to True
        if dist < 200:
            collided= True
    #If collided is True, then the generateAsteroid() function is called again, the resulting value is assigned to a and a is returned        
    if collided == True:
        a= generateAsteroid(canvas)
        return a
    #asteroid is returned to wherever this function was called
    return asteroid
#This function creates asteroids when it is called
def createAsteroids():
    #The for loop below runs for the variable x in range 10
    for x in range(10):
        #The generateAsteroid() function is called here and the resulting value is assigned to the asteroid variable
        asteroid= generateAsteroid(canvas)
        #asteroid is appended to the Asteroids list
        Asteroids.append(asteroid)
# This function resets the Asteroids list so that it has 0 asteroid objects
def deleteAllAsteroids():
    global Asteroids 
    Asteroids= []
#This function resets the Bullets list so that it has 0 bullet objects. All bullet images are deleted as well    
def deleteAllBullets():
    global Bullets
    for bullet in Bullets:
        bullet.deleteBulletImage()
    Bullets= []
#This function asks the player if they want to play the game again and takes action based on their answer    
def askPlayAgain():
    global winner, spaceship, pointsSpaceship, textpointsSpaceship, points, health
    answer= messagebox.askyesno("Asterpocalypse", "GAME OVER!\nYou had " + str(pointsSpaceship) + " points.\nDo you want to play the game again?")
    #If the user clicks "Yes", then the commands below will run
    if answer == True:
        #pointsSpaceship and points are both set to 0
        pointsSpaceship= 0
        points= 0
        health=10
        #textpointsSpaceship is configured to show the updated pointsSpaceship
        canvas.itemconfig(textpointsSpaceship, text=str(pointsSpaceship))
        #A new Spaceship object is created and assigned to the spaceship variable
        spaceship= Spaceship(canvas, x=0, y=70)
        #deleteAllBullets(), deleteAllAsteroids(), createAsteroids(), and checkhealth() are called here
        deleteAllBullets()
        deleteAllAsteroids()
        createAsteroids()
        checkhealth()
        #The btid, gameid, collisionSpaceshipId, and collisionBulletId timers are restarted here
        btid = root.after(50, lambda: background_timer())
        gameid= root.after(60, lambda: game())
        collisionSpaceshipId= root.after(20, collisionCheckSpaceship)
        collisionBulletId= root.after(20, collisionCheckBullets)
    #Otherwise, the program is closed
    elif answer == False:
        messagebox.showinfo("Asterpocalypse", "Thank you for playing Asterpocalypse")
        exit_program()
#This function asks the user if they want to keep playing after they lose a life
def askPlayAfterLostLife():
    global health
    answer= messagebox.askyesno("Asterpocalypse", "You lost a life!\nDo you want to continue the game")
    #If answer is True, then the commands below will run
    if answer == True:
        #The resetImage() function is called here
        spaceship.resetImage()
        # I reset the health of the player as well as the health bar
        health=10
        checkhealth()
        #The deleteAllBullets(), deleteAllAsteroids() and createAsteroids() functions are called here
        deleteAllBullets()
        deleteAllAsteroids()
        createAsteroids()
        #The btid, gameid, collisionSpaceshipId, and collisionBulletId timers are restarted here
        btid = root.after(50, lambda: background_timer())
        gameid= root.after(60, lambda: game())
        collisionSpaceshipId= root.after(20, collisionCheckSpaceship)
        collisionBulletId= root.after(20, collisionCheckBullets)
    #Otherwise, the program is closed
    elif answer == False:
        messagebox.showinfo("Asterpocalypse", "Thank you for playing Asterpocalypse")
        exit()
#This function plays a certain sound effect (depending on the value passed to it) when it is called 
def playSound(idx):
    pygame.mixer.Sound.play(soundEffects[idx])

#A new window is initialized by using the Tk() function 
root = Tk()
#Calling the title() function allowed the window to be renamed
root.title('Asterpocalypse')
#I used the protocol() function to install a handler for the close window protocol
root.protocol('WM_DELETE_WINDOW', exit_program)
#The background image and title image are converted into PhotoImages and assigned to the imgBackground and imgTitle variables respectively
imgBackground = PhotoImage(file='images/space_background.png')
imgTitle = PhotoImage(file='images/asterpocalypse.png')
#I initialized a pygame mixer, loaded the Soundtrack.mp3 file, and then called the play() function to play the mp3 file
pygame.mixer.init()
pygame.mixer.music.load("audio/Soundtrack.mp3")
pygame.mixer.music.play(loops=0)
#I created a list with all the audio files of the sound effects and named it audioFiles
audioFiles = ['audio/bullet.wav', 'audio/boom.wav']
#I initialized a list and named it soundEffects
soundEffects= [0] * 2
#The for loop below turns each audio file in audioFiles into a Sound object and assigns said Sound object to an index in soundEffects
for x in range(2):
    soundEffects[x]= pygame.mixer.Sound(audioFiles[x])
#The geometry() function is used to define the window's dimensions and to position the window in the middle of the screen
root.geometry("%dx%d+%d+%d" % (imgBackground.width(), imgBackground.height(), root.winfo_screenwidth() // 2 - imgBackground.width() // 2,
    root.winfo_screenheight() // 2 - imgBackground.height() // 2))
#A canvas is created, its properties are set, and the canvas is assigned to the canvas variable. The canvas is then packed onto the window
canvas = Canvas(root, width=imgBackground.width(), height=imgBackground.height())
canvas.pack()
background_list = [0] * 2
xpos = [0, imgBackground.width()]
for i in range(len(background_list)):
    background_list[i] = canvas.create_image(xpos[i], 0, image=imgBackground, anchor='nw')
#imgTitle is placed onto the canvas using canvas.create_image
canvas.create_image(canvas.winfo_reqwidth() // 2 - imgTitle.width() // 2, 10, image=imgTitle, anchor='nw')
#A spaceship object is created and assigned to the spaceship variable
spaceship= Spaceship(canvas, x=0, y=70)
#The setSpaceshipLives() function is called here
spaceship.setSpaceshipLives(x=820, y=40, live=3)
#The getPointsSpaceship() function is called here and the resulting value is assigned to pointsSpaceship
pointsSpaceship= spaceship.getPointsSpaceship()
#pointsSpaceship is converted into a string and placed onto the canvas
textpointsSpaceship= canvas.create_text(70, 35, text=str(pointsSpaceship), font=('Neuropol', 30, 'bold'), fill='orange')
#A list of all the PhotoImages of the different health bars is created here and named healthimg
healthimg= [PhotoImage(file="images/health10.png"), PhotoImage(file="images/health9.png"), PhotoImage(file="images/health8.png"), 
        PhotoImage(file="images/health7.png"), PhotoImage(file="images/health6.png"), PhotoImage(file="images/health5.png"),
        PhotoImage(file="images/health4.png"), PhotoImage(file="images/health3.png"), PhotoImage(file="images/health2.png"),
        PhotoImage(file="images/health1.png"), PhotoImage(file="images/health0.png")]
#The full health bar is placed onto the canvas
cvshealth= canvas.create_image(canvas.winfo_reqwidth()-30, 10, image=healthimg[0], anchor="ne" )
#The createAsteroids() function is called here
createAsteroids()
#The background_timer(), game(), collisionCheckSpaceship(), and collisionCheckBullets() functions are called below    
background_timer()
game()
collisionCheckSpaceship()
collisionCheckBullets()
#This root.bind() function calls the onKeyPress() function every time the user clicks a key on the keyboard
root.bind("<KeyPress>", onKeyPress)
#This root.bind() function calls the onMouseClick() function every time the user clicks a button on the mouse
root.bind("<ButtonPress>", onMouseClick)
#Calling the .mainloop() function allows the window to form on the desktop
root.mainloop()

