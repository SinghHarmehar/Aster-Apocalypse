# Author: Faizan Faisal, Harmehar Singh 
# Date: November 1st 2020
# Class: ICS4U with Mr. Bulhao
# Program: Bullet Class
# Description: This is the Bullet class that is used in the Main.py file in this project

# I imported the PhotoImage module from tkinter
from tkinter import PhotoImage
import pygame
# We created a new class and named it Bullet
class Bullet:
    #We created a constructor that takes a canvas value, an x value, and a y value
    def __init__(self, canvas, x=0, y=70):
        '''
        Creates the Bullet object
        
        PARAMETERS:
        -----------
        canvas: frame
            The canvas on which the bullet is supposed to be 
        x: int
            X coordinate of the bullet
        y: int
            Y coordinate of the bullet
        ''' 
        self.__canvas= canvas
        self.__xpos= x 
        self.__ypos= y 
        #We defined the self.__photoBullet, self.__widthBullet, self.__heightBullet, self.__canvasWidth, self.__canvasHeight, and self.__imgBullet variables
        self.__photoBullet= PhotoImage(file="images/laserbeam_red.png")
        self.__widthBullet= self.__photoBullet.width()
        self.__heightBullet= self.__photoBullet.height()
        self.__canvasWidth= self.__canvas.winfo_reqwidth()
        self.__canvasHeight= self.__canvas.winfo_reqheight()
        self.__imgBullet= self.__canvas.create_image(self.__xpos, self.__ypos, image=self.__photoBullet, anchor="nw")

    def setLocation(self, x, y):
        '''
        Sets the location of the bullet.
        PARAMETERS:
        -----------
        x=int
            The x position of the bullet
        y=int
            The y position of the bullet
        
        '''   
        #self.__xpos and self.__ypos is set to x and y respectively
        self.__xpos = x
        self.__ypos= y  
        #The location of the bullet is updated using self.__canvas.coords
        self.__canvas.coords(self.__imgBullet, self.__xpos, self.__ypos)

    def fireBullet(self):
        '''
        Fires the bullet from the spaceship
        '''   
        #self.__xpos is increased by 10 pixels
        self.__xpos += 10
        #The location of the bullet is updated using self.__canvas.coords
        self.__canvas.coords(self.__imgBullet, self.__xpos, self.__ypos)
   
    def getBoundsObject(self):
        '''
        Provides the boundaries at which the image of the bullet begins
         
        RETURNS:
        -----------
        [int, int, int, int]
            The boundaries at which the image of the bullet begins
        ''' 
        x1= self.__canvas.bbox(self.__imgBullet)[0]
        y1= self.__canvas.bbox(self.__imgBullet)[1]
        x2= self.__canvas.bbox(self.__imgBullet)[2]
        y2= self.__canvas.bbox(self.__imgBullet)[3]
        bounds= [x1, y1, x2, y2]
        return bounds

    def getX(self):
        '''
        Returns the x coordinate of the bullet 
        
        RETURNS:
        --------
        int 
            X coordinate of the bullet
        '''   
        return self.__xpos
    
    def getY(self):
        '''
        Returns the y coordinate of the bullet 
        
        RETURNS:
        --------
        int 
            Y coordinate of the bullet
        ''' 
        return self.__ypos  

    def deleteBulletImage(self):
        '''
        Deletes the image of the bullet 
    
        '''   
        self.__canvas.delete(self.__imgBullet)