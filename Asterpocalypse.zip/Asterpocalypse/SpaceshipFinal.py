# Author: Faizan Faisal, Harmehar Singh
# Date: November 1st 2020
# Class: ICS4U with Mr. Bulhao
# Program: Spaceship Class
# Description: This is the Spaceship class that is used in the Main.py file in this project

#The PhotoImage module is imported from tkinter
from tkinter import PhotoImage
import pygame
# We defined a new class and called it Spaceship
class Spaceship:

    def __init__(self, canvas, x=0, y=0):
        '''
        Creates the Spaceship object
        
        PARAMETERS:
        -----------
        canvas: frame
            The canvas on which the bullet is supposed to be 
        x: int
            X coordinate of the spaceship
        y: int
            Y coordinate of the spaceship
        ''' 
        self.__canvas= canvas
        self.__xpos= x
        self.__ypos= y
        #We defined the self.__photoSpaceship, self.__photoDeadSpaceship, self.__photoSpaceshipLives3, self.__photoSpaceshipLives2, self.__photoSpaceshipLives1, self.__spaceshipWidth, self.__spaceshipHeight, self.__imgSpaceship, self.__canvasWidth, 
            #self.__canvasHeight, self.__spaceshipLives, self.__spaceshipPoints and self.__healthBar variables below 
        self.__photoSpaceship= PhotoImage(file="images/spaceship.png")
        self.__photoDeadSpaceship= PhotoImage(file="images/exploded_ship.png")
        self.__photoSpaceshipLives3= PhotoImage(file="images/lives3.png")
        self.__photoSpaceshipLives2= PhotoImage(file="images/lives2.png")
        self.__photoSpaceshipLives1= PhotoImage(file="images/lives1.png")
        self.__spaceshipWidth= self.__photoSpaceship.width()
        self.__spaceshipHeight= self.__photoSpaceship.height()
        self.__imgSpaceship= self.__canvas.create_image(self.__xpos, self.__ypos, image=self.__photoSpaceship, anchor="nw")
        self.__imgSpaceshipLives= self.__canvas.create_image(820, 40, image=self.__photoSpaceshipLives3, anchor="nw")
        self.__canvasWidth= self.__canvas.winfo_reqwidth()
        self.__canvasHeight= self.__canvas.winfo_reqheight()
        self.__spaceshipLives= 3
        self.__spaceshipPoints= 0
        self.__healthBar= 11
   
    def getX(self):
        '''
        Returns the x coordinate of the spaceship 
        
        RETURNS:
        -----------
        int 
            x coordinate of the spaceship 
        ''' 
        return self.__xpos
    
    def getY(self):
        '''
        Returns the y coordinate of the spaceship
        RETURNS:
        -----------
        int 
            y coordinate of the spaceship
        ''' 
        return self.__ypos
    
    def getPhotoSpaceship(self):
        '''
        Returns the image of the spaceship
        
        RETURNS:
        -----------
        PhotoImage 
            Image of the spaceship
        ''' 
        return self.__photoSpaceship
    
    def getWidth(self):
        '''
        Returns the width of the spaceship
        
        RETURNS:
        -----------
        int 
            The width of the spaceship
        ''' 
        return self.__spaceshipWidth

    def getHeight(self):
        '''
        Returns the height of the spaceship 
        
        RETURNS:
        -----------
        int 
            Height of the spaceship
        ''' 
        return self.__spaceshipHeight

    def getSpaceshipLives(self):
        '''
        Returns the amount of lives that the spaceship has left
        
        RETURNS:
        -----------
        int 
            The live(s) of the spaceship
        ''' 
        return self.__spaceshipLives
   
    def getBoundsObject(self):
        '''
        Provides the boundaries at which the image of the spaceship begins
         
        RETURNS:
        -----------
        [int, int, int, int]
            The boundaries at which the image of the spaceship begins
        ''' 
        x1= self.__canvas.bbox(self.__imgSpaceship)[0] + 5
        y1= self.__canvas.bbox(self.__imgSpaceship)[1] + 5
        x2= self.__canvas.bbox(self.__imgSpaceship)[2] - 5
        y2= self.__canvas.bbox(self.__imgSpaceship)[3] - 5
        bounds= [x1, y1, x2, y2]
        return bounds

    def move(self, x=0, y=0):
        '''
        This function moves the spaceship when it is called
        
        PARAMETERS:
        -----------
        x: int
            The amount of pixels to be moved horizontally
        y: int
            The amount of pixels to be moved vertically
        ''' 
        #self.__xpos increases by x
        self.__xpos += x 
        #self.__ypos increases by y
        self.__ypos += y
        #The location of the spaceship is updated using the self.__canvas.coords() function
        self.__canvas.coords(self.__imgSpaceship, self.__xpos, self.__ypos)
    
    def setSpaceshipBoundaries(self, xbounds=0, ybounds=0):
        '''
        Sets the boundaries in which the spaceship is able to move (Note that it is assumed that the bottom and right sides of the window are counted as boundaries)
        
        PARAMETERS:
        -----------
        xbounds: int
            The top horizontal boundary
        ybounds: int
            The left vertical boundary
        ''' 
        #If self.__xpos is smaller than xbounds, the code below will run
        if self.__xpos < xbounds:

            #self.__xpos is set to xbounds
            self.__xpos= xbounds
        #If self.__xpos is bigger than self.__canvasWidth subtracted by self.__spaceshipWidth, the code below will run
        elif self.__xpos > self.__canvasWidth - self.__spaceshipWidth:
            #self.__xpos is set to self.__canvasWidth subtracted by self.__spaceshipWidth
            self.__xpos= self.__canvasWidth - self.__spaceshipWidth
        #If self.__ypos is smaller than ybounds, the code below will run    
        if self.__ypos < ybounds:
            #self.__ypos is set to ybounds
            self.__ypos= ybounds
        #If self.__ypos is bigger than self.__canvasHeight subtracted by self.__spaceshipHeight
        elif self.__ypos > self.__canvasHeight - self.__spaceshipHeight + 4:
            #self.__ypos is set to self.__canvasHeight subtracted by self.__spaceshipHeight
            self.__ypos= self.__canvasHeight - self.__spaceshipHeight + 4
        #The location of the spaceship is updated using the self.__canvas.coords() function
        self.__canvas.coords(self.__imgSpaceship, self.__xpos, self.__ypos)
    
    def setSpaceshipLives(self, x=0, y=0, live=3):
        '''
        Sets the amount of lives that the player has 
        
        PARAMETERS:
        -----------
        x: int
            The x position of the spaceship
        y: int
            The y position of the spaceship
        live: int
            The amount of lives the spaceship has left
        ''' 
        if self.__spaceshipLives == 3:
            self.__canvas.itemconfig(self.__imgSpaceshipLives, image=self.__photoSpaceshipLives3) 
        elif self.__spaceshipLives == 2:
            self.__canvas.itemconfig(self.__imgSpaceshipLives, image=self.__photoSpaceshipLives2) 
        elif self.__spaceshipLives == 1:
            self.__canvas.itemconfig(self.__imgSpaceshipLives, image=self.__photoSpaceshipLives1) 
       
    def getPointsSpaceship(self, val=0):
        '''
        Update's and returns the player's points
        
        PARAMETERS:
        -----------
        val: int
            The point value of the asteroid
             
        RETURNS:
        -----------
        int
            the player's total points
        ''' 
        self.__spaceshipPoints += val
        return self.__spaceshipPoints
             
    def destroySpaceship(self):
        '''
        Destroys the spaceship by changing the image of the spaceship into the image of an explosion
        
        RETURNS:
        -----------
        int
            The amount of lives left for the spaceship
        ''' 
        self.__canvas.itemconfig(self.__imgSpaceship, image=self.__photoDeadSpaceship)
        self.__spaceshipLives -= 1
        return self.__spaceshipLives
    
    def resetImage(self):
        '''
        Changes the image of the spaceship back into the image of the normal spaceship
        ''' 
        self.__canvas.itemconfig(self.__imgSpaceship, image=self.__photoSpaceship)
        