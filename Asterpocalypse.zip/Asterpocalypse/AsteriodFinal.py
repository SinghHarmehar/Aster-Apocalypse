# Author: Faizan Faisal, Harmehar Singh
# Date: November 1st 2020
# Class: ICS4U with Mr. Bulhao
# Program: Asteroid Class
# Description: This is the Asteroid class that is used in the Main.py file in this project

#I imported the PhotoImage module from tkinter
from tkinter import PhotoImage
import pygame

#We created a new class and named it Asteroid
class Asteroid:
    
    def __init__(self, canvas, typeAsteroid=1, x=1000, y=70):
        '''
        This is the constructor of the Asteroid class
        
        PARAMETERS:
        -----------
        canvas: frame
            Canvas on which the asteroid is stored
             
        typeAsteroid:int
            The number for the type of asteroid
            
        x: int
            X coordinate of the asteroid
            
        y: int
            Y coordinate of the asteroid
        
        ''' 
        self.__canvas= canvas
        self.__type= typeAsteroid
        self.__xpos= x 
        self.__ypos= y
        #If self.__type is equal to 1, then the commands below will run
        if self.__type == 1:
            #We defined a self.__livesAsteroid, self.__photoAsteroid, self.__photoDeadAsteroid, self.__widthAsteroid, and self.__heightAsteroid variable
            self.__livesAsteroid= 1
            self.__photoAsteroid= PhotoImage(file="images/asteroid0.png")
            self.__photoDeadAsteroid= PhotoImage(file="images/explosion0.png")
            self.__widthAsteroid= self.__photoAsteroid.width()
            self.__heightAsteroid= self.__photoAsteroid.height()
        #If self.__type is equal to 2, then the commands below will run
        elif self.__type == 2:
            #We defined a self.__livesAsteroid, self.__photoAsteroid, self.__photoDeadAsteroid, self.__widthAsteroid, and self.__heightAsteroid variable
            self.__livesAsteroid= 2
            self.__photoAsteroid= PhotoImage(file="images/asteroid1.png")
            self.__photoDeadAsteroid= PhotoImage(file="images/explosion1.png")
            self.__widthAsteroid= self.__photoAsteroid.width()
            self.__heightAsteroid= self.__photoAsteroid.height()
        #If self.__type is equal to 3, then the commands below will run
        elif self.__type == 3:
            #We defined a self.__livesAsteroid, self.__photoAsteroid, self.__photoDeadAsteroid, self.__widthAsteroid, and self.__heightAsteroid variable
            self.__livesAsteroid= 3
            self.__photoAsteroid= PhotoImage(file="images/asteroid2.png")
            self.__photoDeadAsteroid= PhotoImage(file="images/explosion2.png")
            self.__widthAsteroid= self.__photoAsteroid.width()
            self.__heightAsteroid= self.__photoAsteroid.height()
        #We also defined a self.__imgAsteroid, self.__canvasWidth, and self.__canvasHeight variable    
        self.__imgAsteroid= self.__canvas.create_image(self.__xpos, self.__ypos, image=self.__photoAsteroid, anchor="nw")
        self.__canvasWidth= self.__canvas.winfo_reqwidth()
        self.__canvasHeight= self.__canvas.winfo_reqheight()
           
    def getWidth(self):
        '''
        Returns the width of the asteroid
        
        RETURNS:
        -----------
        int 
            Width of the asteroid 
        '''   
        return self.__widthAsteroid
        
    def getHeight(self):
        '''
        Returns the height of the asteroid  
        
        RETURNS:
        -----------
        int 
            Height of the asteroid 
        ''' 
        return self.__heightAsteroid
    
    def getAsteroidLives(self):
        '''
        Gets the amount of lives the asteroid object has left
        
        RETURNS:
        -----------
        int 
            The lives of the asteroid 
        ''' 
        return self.__livesAsteroid
        
    def getImgAsteroid(self):
        '''
        Gets the image of the asteroid
        
        RETURNS:
        -----------
        file/ (int)
            The image of the asteroid 
        ''' 
        return self.__imgAsteroid
    
    def move(self):
        '''
        Moves the asteroid 10 pixels to the left each time it is called
        
        RETURNS:
        -----------
        NONE 
        ''' 
        #self.__xpos decreases by 10 pixels
        self.__xpos -= 10
        #The location of the bullet is updated using self.__canvas.coords
        self.__canvas.coords(self.__imgAsteroid, self.__xpos, self.__ypos)
   
    def getX(self):
        '''
        Provides the x coordinate of the asteroid object
        
        RETURNS:
        -----------
        int
            The x position of the asteroid 
        ''' 
        return self.__xpos
    
    def getY(self):
        '''
        Provides the x coordinate of the asteroid object
        
        RETURNS:
        -----------
        int
            The x position of the asteroid
        ''' 
        return self.__ypos  
    
    def getBoundsObject(self):
        '''
        Provides the boundaries at which the image of the asteroid begins
         
        RETURNS:
        -----------
        [int, int, int, int]
            The boundaries at which the image of the asteroid begins
        ''' 
        x1= self.__canvas.bbox(self.__imgAsteroid)[0] + 10
        y1= self.__canvas.bbox(self.__imgAsteroid)[1] + 10
        x2= self.__canvas.bbox(self.__imgAsteroid)[2] - 10
        y2= self.__canvas.bbox(self.__imgAsteroid)[3] - 10
        bounds= [x1, y1, x2, y2]
        return bounds
    
    def destroyAsteroid(self):
        '''
        This function destroys the asteroid when it is called
         
        RETURNS:
        -----------
        int
            The amount of lives the asteroid object has left
        ''' 
        #self.__livesAsteroid decreases by 1
        self.__livesAsteroid -= 1
        #If self.__livesAsteroid is 0, self.__imgAsteroid is configured to show self.__photoDeadAsteroid
        if self.__livesAsteroid == 0:
            self.__canvas.itemconfig(self.__imgAsteroid, image=self.__photoDeadAsteroid)
        #self.__livesAsteroid is returned to where the function is called
        return self.__livesAsteroid
    
    def deleteAsteroidImg(self):
        '''
        This function deletes self.__imgAsteroid
         
        RETURNS:
        -----------
        NONE
        ''' 
        self.__canvas.delete(self.__imgAsteroid)
     
    def setPointsSpaceship(self):
        '''
        This function sets the points variable based on what sized asteroid the user destroyed 
         
        RETURNS:
        -----------
        int
            The points variable based on what sized asteroid the user destroyed 
        ''' 
        if self.__type == 1:
            points = 10
        elif self.__type == 2:
            points= 20
        elif self.__type == 3:
            points= 30
        #points is returned to wherever the function is called
        return points
